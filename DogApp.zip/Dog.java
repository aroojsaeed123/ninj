public class Dog {

    // instance variables
     String Dogtype;
     String DogName;
     String DogBreed;
     

    // constructor


    // methods
    public string settopTrick()
    {
    	return topTrick;
    	
    }

    // method used to print Dog information
    public String toString() {
        String temp = "\nDOG DATA\n" + DogName + " is a " + DogBreed +
                ", a " + Dogtype + " dog. \nThe top trick is : " +
                topTrick + ".";
        return temp;
    }

}
